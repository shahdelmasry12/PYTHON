# #f-string
# name="shahd"
# age=20
# message= f"Hello {name} you are { age} years old"
# print (message)
#*************************************************************
# #escape characters
# # print(it's good) get error
# print('it\'s good') #get it's good 
# print("it's good") #get it's good 
# # print("it's "good"") #get error 
# print("it's \"good\"") #get it's "good"

# # \n to start new line
# print(" what's your name?\n my name is shahd")
# # to add some space to strings
# print("\t what's your name?")


