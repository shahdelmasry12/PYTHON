n1, n2 ,n3= map(int, input().split())
print(int((n1+n2+n3)/3))