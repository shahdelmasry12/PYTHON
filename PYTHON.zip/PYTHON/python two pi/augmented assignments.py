num_students=num_students+1#num_students+=1
price=price*0.9#price*=0.9
balance=balance-price#balance-=price
#*************************************************
r=float(input("enter the r num: "))
pi=3.14
area=pi*r**2
print(f"the area=  {area:.2f}")
#*******************************************
