n1, n2 = map(int, input().split())
n3=str(input().strip())
if n3=='+':
    print(n1+n2)
elif n3=='-':
     print(n1-n2)
elif n3=='*':
    print(n1*n2)
elif n3=='/':
     print(int(n1/n2))   
    
