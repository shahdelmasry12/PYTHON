# full_name=input("Enter your name:")
# country=input("Enter yuor country:")
# print("Hello ",full_name)#?   ??????????????????
# print("you are from ",country)
# to check from temperature
temperature=float(input("Enter the temperature: "))
if temperature<20:
    print("it's cold") #4 space
print("Done")  