import math as m
import random as r
# print(abs(-3.8))
# print(round(3.4))#back near int num
# print(round(3.8))
# print(min(7,-2,10))
# print(max(7,-2,10))
# print(m.ceil(3.2))
# print(m.floor(3.2))
# print(m.sqrt(9))
# print(m.pow(3,2))#3**2 your will find math modules on programmme w3schools
print(r.random())
print(r.uniform(1,10))
print(r.randint(1,100))
#***************************************************

