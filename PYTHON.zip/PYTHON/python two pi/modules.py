import math as m
from random import randint
print(m.sqrt(25))
print(m.pi)
print(randint(0,20))