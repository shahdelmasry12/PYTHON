s1="learn all about"
s2="python strings"
s2=s2.title()
print (s2)
s3=s1+" "+s2
print(s3)
print(len(s3))
print(s3.find("python"))
print(s3.replace("strings"," "))
